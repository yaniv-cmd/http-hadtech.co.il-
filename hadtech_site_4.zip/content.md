# HadTech - Hadar Representations and Holdings Ltd

## English

Your gateway to the Israeli electronics, defense and industrial market.

HadTech represents manufacturers of passive and active components and complete systems, and provides design, test and manufacturing services across communications, medical and defense.

One partner between your technology and the market. From component and system manufacturers, through HadTech (representation and distribution, design and high-speed circuits, test engineering and DFM, electro-mechanical and production), to markets and applications (communications, medical, defense and industry).

Services: Representation and distribution of passive and active components and systems; Design and development including high-speed communication circuits; Electro-mechanical solutions; Test engineering and final-test definition; Manufacturing and design for manufacturability with cost reduction.

The advantage: an operator, not an agent. HadTech brings a former CEO who reads your BOM, yield, sourcing, DFM and working capital. Executive depth (25+ years of P and L, turnaround and M and A, public company TASE governance). Engineering fluency (hardware, NPI, SMT, reliability). Real access (Israel's defense primes, integrators, industrial and medical OEMs).

Experience: Yaniv Hadar, Founder. 2024-now Founder, Hadar Representations and Holdings. 2013-2025 CEO, EMT (IMCO Group), led a 70 person advanced-electronics manufacturer through a turnaround to a successful exit. 2003-2013 Marvell Semiconductor. 1999-2003 Founder, Shirell System Integration. Board member, Manufacturers Association of Israel.

Domains: Passive components; Active components; Systems; High-speed circuits; RF and microwave; Communications; Medical; Defense and dual-use; Electro-mechanical; Test engineering; DFM and cost reduction.

Contact: info@hadtech.co.il, https://hadtech.co.il/, Israel.

## עברית

שער הכניסה שלכם לשוק האלקטרוניקה, הביטחון והתעשייה בישראל.

HadTech מייצגת יצרני רכיבים פסיביים ואקטיביים ומערכות שלמות, ומספקת שירותי תכנון, בדיקה וייצור בתחומי התקשורת, הרפואה והביטחון.

שירותים: נציגות והפצה של רכיבים פסיביים ואקטיביים ומערכות; תכנון ופיתוח כולל מעגלים במהירות גבוהה; פתרונות אלקטרו-מכניים; הנדסת בדיקות והגדרת בדיקות סופיות; ייצור ותכנון לייצוריות עם הוזלת עלויות.

היתרון: מפעיל, לא סוכן. עומק ניהולי, שטף הנדסי וגישה אמיתית ליצרניות הביטחון, האינטגרטורים ולקוחות התעשייה והרפואה בישראל.

יצירת קשר: info@hadtech.co.il, ישראל.
